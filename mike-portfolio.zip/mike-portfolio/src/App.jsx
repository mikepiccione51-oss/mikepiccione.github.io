import React, { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTrigger, DialogTitle } from "@/components/ui/dialog";
import { Github, Mail, Phone, Download, ExternalLink, Filter, Search, MapPin, CalendarDays } from "lucide-react";
import { motion } from "framer-motion";

const PROFILE = {
  name: "Michael Piccione",
  title: "Operations Supervisor II • Aspiring Data Analyst",
  location: "Chantilly, VA (Relocating)",
  email: "mikepiccione51@gmail.com",
  phone: "540-664-5501",
  summary:
    "Marine Corps veteran and operations leader pivoting into data analytics. Blends logistics expertise with hands-on analytics (Python, R, Power BI, Excel, SQL) to optimize processes, visualize insights, and drive decisions.",
  links: [
    { label: "GitHub", href: "#", icon: Github },
    { label: "Email", href: "mailto:mikepiccione51@gmail.com", icon: Mail },
  ],
};

const SKILLS = {
  analytics: ["Python (pandas, matplotlib)", "R (tidymodels, randomForest)", "SQL", "Power BI", "Excel (Pivot, PowerQuery)", "Statistics (regression, classification)", "Data Cleaning & ETL"],
  ops: ["Logistics & 3PL", "Labor Cost Optimization", "Inventory & WMS", "Process Improvement", "Project Management (RACI, Risk)"],
  soft: ["Leadership", "Stakeholder Comms", "Documentation", "Presentation"]
};

const PROJECTS = [
  { id: "work-labor-cost", title: "Labor Cost Optimization & Capacity Planning", org: "DB Schenker", when: "2024–2025", type: "Work", tools: ["Excel", "Power BI", "SQL"], tags: ["Operations", "Cost", "Dashboards"], summary: "Built daily/weekly labor dashboards and models to align staffing with order volume; reduced OT and improved SLA adherence.", highlights: ["Automated variance reports; flagged exceptions via conditional rules","Modeled headcount needs by inbound/outbound lanes","Presented insights to site leadership; actions cut OT hours measurably"], links: [] },
  { id: "work-racking-design", title: "Racking Design & Throughput Analysis", org: "DB Schenker", when: "2024", type: "Work", tools: ["Excel", "Power BI"], tags: ["Warehouse", "Layout", "KPI"], summary: "Analyzed SKU velocity and storage profiles to recommend racking layout changes; improved picks/foot and travel time.", highlights: ["Mapped ABC velocity to bin locations","Projected travel-time savings vs. baseline","Created what-if scenario views for leadership"], links: [] },
  { id: "work-training-center", title: "Training Center Build & SOP Analytics", org: "DB Schenker", when: "2024", type: "Work", tools: ["Excel", "PowerPoint"], tags: ["Enablement", "SOP", "KPIs"], summary: "Created training SOPs and tracked certification KPIs; reduced ramp time for new associates.", highlights: ["SOP library and checklists", "Onboarding KPI scorecards"], links: [] },
  { id: "sch-amitytech", title: "AmityTech Executive Summary & Compliance Data Validation", org: "SNHU – Project Two/Three", when: "Oct 2025", type: "School", tools: ["Python", "uCertify", "Excel"], tags: ["Data Cleaning", "Validation", "Boxplots"], summary: "Profiled, cleaned, transformed, and merged firm data; validated counts, distributions, and documented results in a formal template.", highlights: ["Row/column count checks pre/post merge","MIN/MAX/AVG distribution review with boxplots","Written summary aligned to rubric (Instructor: Jennifer Johnson)"], links: [] },
  { id: "sch-brfss-al", title: "BRFSS 2017 (Alabama) – Heart Disease Data Prep", org: "SNHU", when: "Apr 2025", type: "School", tools: ["Python (pandas)", "Data Dictionary"], tags: ["Public Health", "EDA", "Cleaning"], summary: "Selected key variables from codebook, standardized types, handled missingness, and documented provenance and quality steps.", highlights: ["Variable relevance mapping to outcomes","Data type harmonization & recoding","Status report with preparation log"], links: [] },
  { id: "sch-credit-default", title: "Logistic Regression – Credit Card Default", org: "SNHU", when: "Apr 2025", type: "School", tools: ["R", "ggplot", "caret"], tags: ["Classification", "ROC/AUC", "HL Test"], summary: "Built two logistic models, evaluated confusion matrix, ROC/AUC, and Hosmer–Lemeshow; interpreted coefficients and predictions.", highlights: ["Compared model specifications","AUC + HL goodness-of-fit reporting","Actionable interpretation for stakeholders"], links: [] },
  { id: "sch-cart-wage", title: "Decision Trees (CART) – Default & Wage Growth", org: "SNHU", when: "Apr 2025", type: "School", tools: ["R", "rpart", "randomForest"], tags: ["Trees", "Regression", "Classification"], summary: "Classification tree for credit default; regression tree for wage growth using macroeconomic predictors; compared performance.", highlights: ["Feature importance & splits","RMSE and misclassification analysis","Model explainability visuals"], links: [] },
  { id: "sch-paysim", title: "Fraud Detection Codebook Revision – PaySim", org: "SNHU – Project Three", when: "Apr 2025", type: "School", tools: ["Documentation", "Data Dictionary"], tags: ["Fraud", "PaySim", "Data Governance"], summary: "Revised and standardized a codebook for the Synthetic Financial Dataset for Fraud Detection; clarified variable semantics.", highlights: ["Naming conventions & value domains","Ambiguity resolution & examples","Client-focused deliverable"], links: [] },
  { id: "sch-asteroid-rf", title: "Random Forest – Asteroid Size & Diameter", org: "SNHU", when: "Apr 2025", type: "School", tools: ["R", "randomForest"], tags: ["Ensembles", "Feature Importance"], summary: "Modeled asteroid diameter from orbital features; tuned hyperparameters and reported variable importance.", highlights: ["Cross-validation", "MAE/RMSE comparison", "Top predictors identified"], links: [] },
  { id: "sch-pbi-sales", title: "Power BI – Sales & Inventory Trends", org: "SNHU / Professional", when: "Jul 2025", type: "School", tools: ["Power BI", "DAX"], tags: ["Dashboards", "Time Series"], summary: "Preliminary analysis of sales/inventory data, monthly trends, top revenue products, and supply challenges for leadership.", highlights: ["Dynamic slicers & drillthrough", "YTD vs. prior year", "Top N visuals"], links: [] },
  { id: "sch-xyz-waterfall", title: "XYZ Financial Services – Waterfall Project Plan", org: "SNHU – PM Plan", when: "May 2025", type: "School", tools: ["PM Artifacts"], tags: ["WBS", "RACI", "Risk Register"], summary: "Complete PM plan with stakeholder & risk registers, WBS, network diagram, and RACI matrix for a software project.", highlights: ["Critical path & dependencies", "Mitigation strategies", "Communication plan"], links: [] },
  { id: "sch-pr-paulfrank", title: "PR Ethics & Misappropriation – Paul Frank Case", org: "SNHU – COM-227", when: "May 2025", type: "School", tools: ["AP Style", "Ethics Codes"], tags: ["PR", "Ethics", "Case Study"], summary: "Analyzed Paul Frank Industries misappropriation case; framed messaging and ethical recommendations.", highlights: ["Crisis comms structure", "Stakeholder mapping", "Policy implications"], links: [] },
];

const TAGS = Array.from(new Set(PROJECTS.flatMap(p => p.tags)));
const TYPES = ["All", "Work", "School"];

function ProjectCard({ p }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-2xl shadow-sm hover:shadow-md transition bg-white border">
      <div className="p-4 border-b">
        <h3 className="text-xl font-semibold">{p.title}</h3>
        <div className="text-sm text-muted-foreground flex items-center gap-3">
          <span className="inline-flex items-center gap-1"><CalendarDays className="h-4 w-4"/>{p.when}</span>
          <span>•</span>
          <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4"/>{p.org}</span>
        </div>
      </div>
      <div className="p-4 space-y-3">
        <p className="text-sm leading-relaxed">{p.summary}</p>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary">{p.type}</Badge>
          {p.tools.map(t => <Badge key={t} variant="outline">{t}</Badge>)}
        </div>
        <span onClick={()=>setOpen(true)}>
          <Button variant="outline" className="mt-1">View details</Button>
        </span>
        {open && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogContent className="rounded-2xl max-w-2xl w-[90vw]">
              <DialogHeader><DialogTitle>{p.title}</DialogTitle></DialogHeader>
              <div className="p-4 space-y-4">
                <p className="text-sm text-muted-foreground">{p.summary}</p>
                <ul className="list-disc pl-5 text-sm space-y-1">
                  {p.highlights.map((h, i) => <li key={i}>{h}</li>)}
                </ul>
                {p.links && p.links.length>0 && (
                  <div className="flex gap-2 flex-wrap">
                    {p.links.map((l,i) => (
                      <Button key={i} asChild variant="ghost" size="sm">
                        <a href={l.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1">
                          <ExternalLink className="h-4 w-4" /> {l.label}
                        </a>
                      </Button>
                    ))}
                  </div>
                )}
                <div className="pt-2">
                  <Button variant="outline" onClick={()=>setOpen(false)}>Close</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [q, setQ] = useState("");
  const [type, setType] = useState("All");
  const [tag, setTag] = useState("All");

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return PROJECTS.filter(p => {
      const matchesType = type === "All" || p.type === type;
      const matchesTag = tag === "All" || p.tags.includes(tag);
      const text = `${p.title} ${p.org} ${p.summary} ${p.tools.join(" ")} ${p.tags.join(" ")}`.toLowerCase();
      const matchesQ = s === "" || text.includes(s);
      return matchesType && matchesTag && matchesQ;
    });
  }, [q, type, tag]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-slate-50">
      <header className="sticky top-0 z-40 backdrop-blur bg-white/75 border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-slate-900" />
            <div>
              <div className="font-semibold">{PROFILE.name}</div>
              <div className="text-xs text-muted-foreground">{PROFILE.title}</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-2">
            <a href="#projects" className="text-sm px-3 py-2 rounded-xl hover:bg-slate-100">Projects</a>
            <a href="#skills" className="text-sm px-3 py-2 rounded-xl hover:bg-slate-100">Skills</a>
            <a href="#experience" className="text-sm px-3 py-2 rounded-xl hover:bg-slate-100">Experience</a>
            <a href="#contact" className="text-sm px-3 py-2 rounded-xl hover:bg-slate-100">Contact</a>
          </nav>
          <div className="flex items-center gap-2">
            {PROFILE.links.map((l) => (
              <Button key={l.label} asChild variant="ghost" size="sm" className="rounded-xl">
                <a href={l.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1">
                  {l.icon && <l.icon className="h-4 w-4" />} {l.label}
                </a>
              </Button>
            ))}
            <Button asChild size="sm" className="rounded-xl">
              <a href="#resume"><Download className="h-4 w-4 mr-1" /> Resume</a>
            </Button>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-5 gap-6 items-center">
        <div className="md:col-span-3">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">Hi, I’m Michael — I turn messy operations data into clear decisions.</h1>
          <p className="mt-3 text-slate-600 leading-relaxed">{PROFILE.summary}</p>
          <div className="mt-4 flex flex-wrap gap-2 text-sm text-slate-600">
            <span className="inline-flex items-center gap-2"><MapPin className="h-4 w-4" /> {PROFILE.location}</span>
            <span className="inline-flex items-center gap-2"><Mail className="h-4 w-4" /> {PROFILE.email}</span>
            <span className="inline-flex items-center gap-2"><Phone className="h-4 w-4" /> {PROFILE.phone}</span>
          </div>
        </div>
        <div className="md:col-span-2">
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>Core Proficiencies</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div>
                <div className="font-medium mb-1">Data & Analytics</div>
                <div className="flex flex-wrap gap-2">{SKILLS.analytics.map(s => <Badge key={s} variant="secondary">{s}</Badge>)}</div>
              </div>
              <div>
                <div className="font-medium mb-1">Operations</div>
                <div className="flex flex-wrap gap-2">{SKILLS.ops.map(s => <Badge key={s} variant="secondary">{s}</Badge>)}</div>
              </div>
              <div>
                <div className="font-medium mb-1">Communication</div>
                <div className="flex flex-wrap gap-2">{SKILLS.soft.map(s => <Badge key={s} variant="secondary">{s}</Badge>)}</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="projects" className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-4">
          <h2 className="text-2xl font-semibold">Projects</h2>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-2">
              <Input value={q} onChange={e => setQ(e.target.value)} placeholder="Search projects..." className="w-56" />
              <Button variant="outline" className="rounded-xl"><Search className="h-4 w-4 mr-2" />Search</Button>
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <Tabs value={type} onValueChange={(v) => setType(v)}>
                <TabsList className="rounded-xl">
                  {TYPES.map(t => <TabsTrigger key={t} value={t} className="rounded-xl">{t}</TabsTrigger>)}
                </TabsList>
              </Tabs>
              <select value={tag} onChange={(e) => setTag(e.target.value)} className="text-sm border rounded-xl px-2 py-2 bg-white">
                <option>All</option>
                {TAGS.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
          </div>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((p) => <ProjectCard key={p.id} p={p} />)}
        </div>
      </section>

      <section id="experience" className="max-w-6xl mx-auto px-4 py-10">
        <h2 className="text-2xl font-semibold mb-4">Experience</h2>
        <div className="grid md:grid-cols-2 gap-5">
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>DB Schenker — Operations Supervisor II</CardTitle></CardHeader>
            <CardContent className="text-sm space-y-2">
              <ul className="list-disc pl-5 space-y-1">
                <li>Lead warehouse operations; align staffing with SLAs and volume forecasts.</li>
                <li>Built analytics to reduce overtime and improve pick/pack throughput.</li>
                <li>Created SOPs and onboarding analytics for a training center initiative.</li>
              </ul>
            </CardContent>
          </Card>
          <Card className="rounded-2xl">
            <CardHeader><CardTitle>U.S. Marine Corps — Veteran</CardTitle></CardHeader>
            <CardContent className="text-sm">
              <p>Leadership under pressure, mission planning, and team development that carry into data-driven operations.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section id="resume" className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid md:grid-cols-3 gap-6 items-center">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-semibold">Resume & Case Study Pack</h2>
            <p className="text-slate-600 mt-2 text-sm">Attach your latest PDF resume and project PDFs here. Replace the links below once uploaded or hosted (e.g., GitHub Releases, Google Drive, or your site).</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button asChild variant="secondary" className="rounded-xl"><a href="#" target="_blank" rel="noreferrer"><Download className="h-4 w-4 mr-2"/>Download Resume (PDF)</a></Button>
              <Button asChild variant="secondary" className="rounded-xl"><a href="#" target="_blank" rel="noreferrer">Case Study Bundle</a></Button>
            </div>
          </div>
          <div>
            <div className="text-sm mb-2">Polish & content completeness</div>
            <Progress value={78} className="h-2" />
            <div className="text-xs text-slate-500 mt-1">Add screenshots, links, and metrics to hit 100%.</div>
          </div>
        </div>
      </section>

      <section id="contact" className="max-w-6xl mx-auto px-4 py-10">
        <Card className="rounded-2xl">
          <CardHeader><CardTitle>Get in touch</CardTitle></CardHeader>
          <CardContent className="text-sm space-y-2">
            <p>Open to data analyst roles (remote or hybrid) and operations analytics roles. Let’s talk about how I can help your team move faster with data.</p>
            <div className="flex flex-wrap gap-2 items-center">
              <Button asChild className="rounded-xl"><a href="mailto:mikepiccione51@gmail.com">Email</a></Button>
              <Button asChild variant="outline" className="rounded-xl"><a href="#">GitHub</a></Button>
              <Badge variant="secondary">{PROFILE.phone}</Badge>
            </div>
          </CardContent>
        </Card>
      </section>

      <footer className="text-center text-xs text-slate-500 py-8">© {new Date().getFullYear()} {PROFILE.name}. Built with React, Tailwind, and minimal UI.</footer>
    </div>
  );
}
