import React from 'react'
export function Dialog({ open, onOpenChange, children }) {
  return <div>{open ? children : null}</div>
}
export function DialogTrigger({ asChild=false, children, ...props }){
  const Comp = asChild ? 'span' : 'button'
  return <Comp onClick={props.onClick}>{children}</Comp>
}
export function DialogContent({ className='', children }){
  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center`}>
      <div className="fixed inset-0 bg-black/40" />
      <div className={`relative bg-white border rounded-2xl max-h-[80vh] overflow-auto ${className}`}>
        {children}
      </div>
    </div>
  )
}
export function DialogHeader({ children }){ return <div className="p-4 border-b">{children}</div> }
export function DialogTitle({ children }){ return <h3 className="font-semibold">{children}</h3> }
