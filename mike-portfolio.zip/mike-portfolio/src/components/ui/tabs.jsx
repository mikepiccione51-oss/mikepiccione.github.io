import React, { createContext, useContext } from 'react'
const TabsCtx = createContext({ value:'', onChange:()=>{} })
export function Tabs({ value, onValueChange, children }) {
  return <TabsCtx.Provider value={{ value, onChange:onValueChange }}>{children}</TabsCtx.Provider>
}
export function TabsList({ className='', children }){
  return <div className={`inline-flex border rounded-xl p-1 ${className}`}>{children}</div>
}
export function TabsTrigger({ value, className='', children }) {
  const { value:cur, onChange } = useContext(TabsCtx)
  const active = cur===value
  return (
    <button onClick={()=>onChange?.(value)} className={`px-3 py-1.5 text-sm rounded-xl ${active?'bg-slate-900 text-white':'hover:bg-slate-100'} ${className}`}>
      {children}
    </button>
  )
}
export function TabsContent({ value, children }){
  const { value:cur } = useContext(TabsCtx)
  if (cur!==value) return null
  return <div className="mt-2">{children}</div>
}
