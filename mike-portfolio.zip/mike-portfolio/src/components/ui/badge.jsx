import React from 'react'
export function Badge({ variant='default', className='', children }){
  const variants={ default:'bg-slate-900 text-white', secondary:'bg-slate-100', outline:'border' }
  return <span className={`inline-block px-2.5 py-1 text-xs rounded-full ${variants[variant]} ${className}`}>{children}</span>
}
