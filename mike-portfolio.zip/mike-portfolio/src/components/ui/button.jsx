import React from 'react'
export function Button({ asChild=false, variant='default', size='md', className='', children, ...props }) {
  const base='inline-flex items-center justify-center font-medium transition focus:outline-none'
  const radius='rounded-xl'
  const sizes = { sm:'px-3 py-1.5 text-sm', md:'px-4 py-2 text-sm' }
  const variants = {
    default:'bg-slate-900 text-white hover:bg-slate-800',
    outline:'border bg-white hover:bg-slate-50',
    ghost:'hover:bg-slate-100',
    secondary:'bg-slate-100 hover:bg-slate-200'
  }
  const cls = `${base} ${radius} ${sizes[size]} ${variants[variant]} ${className}`
  const Comp = asChild ? 'span' : 'button'
  return <Comp className={cls} {...props}>{children}</Comp>
}
